<!-- Created by tianxubo on 2018/6/19 -->
<template>
    <div id="RecordList">
      <!-- 记录头部 -->
      <div class="record_head">
        <ul>
          <li>
            <span>当前账户：</span>
            <div class="check_account">
              <p>TEST ON</p>
              <div class="account_list" v-show="false">
                <p>TEST 1</p>
                <p>TEST 2</p>
                <p>TEST 3</p>
                <p>TEST 4</p>
              </div>
            </div>
          </li>
          <li>
            <span>地址：</span>
            <div class="right_div">
              <p>LETsdfsfsdfsdfsdfsdfsfsdfsdf</p>
              <i></i>
            </div>
          </li>
          <li>
            <span>账户余额：</span>
            <div class="right_div">
              <p class="orange_p">1000.1LET</p>
            </div>
          </li>
        </ul>
      </div>

      <!-- 记录列表 -->
      <div class="record_table">
        <div class="table_header">
          <span>时间</span>
          <span>备注</span>
          <span>手续费</span>
          <span>账户余额</span>
          <span>交易金额</span>
          <span>对方账户</span>
          <span>状态</span>
        </div>
        <ul>
          <li>
            <span>时间</span>
            <span>备注</span>
            <span>手续费</span>
            <span>账户余额</span>
            <span>交易金额</span>
            <span>对方账户</span>
            <span>状态</span>
          </li>
          <li>
            <span>时间</span>
            <span>备注</span>
            <span>手续费</span>
            <span>账户余额</span>
            <span>交易金额</span>
            <span>对方账户</span>
            <span>状态</span>
          </li>
          <li>
            <span>时间</span>
            <span>备注</span>
            <span>手续费</span>
            <span>账户余额</span>
            <span>交易金额</span>
            <span>对方账户</span>
            <span>状态</span>
          </li>
          <li>
            <span>时间</span>
            <span>备注</span>
            <span>手续费</span>
            <span>账户余额</span>
            <span>交易金额</span>
            <span>对方账户</span>
            <span>状态</span>
          </li>
          <li>
            <span>时间</span>
            <span>备注</span>
            <span>手续费</span>
            <span>账户余额</span>
            <span>交易金额</span>
            <span>对方账户</span>
            <span>状态</span>
          </li>
          <li>
            <span>时间</span>
            <span>备注</span>
            <span>手续费</span>
            <span>账户余额</span>
            <span>交易金额</span>
            <span>对方账户</span>
            <span>状态</span>
          </li>
        </ul>
      </div>

        <!-- Write your HTML with Vue in here -->
    </div>
</template>

<script>
    export default {
        // Write your Vue component logic here
        data(){
            return {}
        },
        mounted: function () {

        },
        methods: {}
    }
</script>

<style lang="scss" scoped>
    /* Write your styles for the component in here */
  #RecordList{
    .record_head{
      background: #ffffff;
      border-bottom: 1px solid #E1E2E3;
      padding: 22px 0 22px 11px;

      ul{
        li:nth-child(1){
          margin-left:0px;
        }
        li{
          display: inline-block;
          margin-left: 63px;
          vertical-align: middle;
          &>span{
            font-size: 16px;
            color: #333333;
            display: inline-block;
          }
          &>div,&>p{
            display: inline-block;
          }
          .check_account{
            display: inline-block;
            width:106px;
            height: 24px;
            background: #F6F7FE;
            border:1px solid #788CF5;
            border-radius: 3px;
            position: relative;
            &>p{
              color: #788CF5;
              font-size: 16px;
              line-height: 24px;
              text-align: center;
            }

            .account_list{
              position: absolute;
              top:25px;
              width:106px;
              height:96px;
              background: #F6F7FE;
              border:1px solid #788CF5;
              border-top:0 solid #788CF5;
              left: -1px;
              border-radius: 0 0 3px 3px;
              /*overflow: scroll;*/
              p{
                color: #788CF5;
                font-size: 16px;
                line-height: 24px;
                text-align: center;
              }
            }
          }

          .right_div{
            p{
              color: #788CF5;
              font-size: 16px;
              display: inline-block;
            }
            i{
              width:18px;
              height: 18px;
              background: url(./img/address_icon.png) no-repeat center;
              background-size: 100%;
              display: inline-block;
              margin-left: 20px;
              position: relative;
              top:2px;
            }
            p.orange_p{
              color: #F9A038;
            }
          }
        }
      }
    }

    .record_table{
      .table_header{
        background: #ffffff;
        text-align: center;
        color: #333333;
        height:40px;
        font-weight: 600;
        display: flex;
        span{
          /*display: inline-block;*/
          flex: 1;
          line-height: 40px;
          font-size: 14px;
          text-align: center;
        }
      }

      ul{
        li{
          display: flex;
          height:40px;
          line-height: 40px;
          span{
            flex: 1;
            font-size: 14px;
            color: #333333;
            text-align: center;
          }
        }

        li:nth-child(odd){
          background: #F6F7FE;
        }
        li:nth-child(even){
          background: #ffffff;
        }
      }
    }
  }
</style>
